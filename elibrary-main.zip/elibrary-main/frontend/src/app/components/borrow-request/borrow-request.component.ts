import { Component } from '@angular/core';

@Component({
  selector: 'app-borrow-request',
  standalone: true,
  imports: [],
  templateUrl: './borrow-request.component.html',
  styleUrl: './borrow-request.component.css'
})
export class BorrowRequestComponent {

}
